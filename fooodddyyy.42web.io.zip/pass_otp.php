<?
include 'include/connect.php';
include 'include/header.php';

?>

<div class="form-container">
      <form action="" method="post">
         <h3>Forgate Password</h3>
         <input type="number" id="otp" name="otp" placeholder="Enter the otp" class="box">
         <span id="email-error" class="error"></span>